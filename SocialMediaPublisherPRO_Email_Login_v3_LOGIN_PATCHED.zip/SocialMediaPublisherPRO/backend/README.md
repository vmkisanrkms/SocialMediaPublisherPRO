# Supabase backend — Social Media Publisher PRO

Project: `kzczivaydandiqgnzfeg`
Private schema: `smp_private` (backend-only; not exposed through PostgREST).

Implemented database foundation includes organizations, organization_members,
social_accounts, oauth_credentials, posts, post_variants, post_media, post_reviews,
publish_jobs, publish_results, account_health and activity_logs.

Authenticated RPCs:
- `smp_bootstrap_org(p_org_name text)`
- `smp_save_draft(p_organization_id uuid, p_title text, p_base_text text, p_platforms text[])`
- `smp_list_drafts(p_organization_id uuid)`

Private Storage bucket: `social-media-assets` (50 MiB limit; image/video MIME allowlist).
Object path: `<organization_uuid>/<user_uuid>/<filename>`.

Mobile authentication uses Supabase Auth email/password and refresh-token grant.
Tokens are stored using AndroidX EncryptedSharedPreferences. Only the publishable
key is included in the APK. Never embed service_role or provider OAuth secrets.

Password recovery sends an email using redirect URI `socialpublisher://auth/reset`.
Configure this URI in Supabase Auth URL Configuration and implement/test the deep-link
password-update screen before production.

Still required: password reset deep-link screen, initial workspace-name setup, secure
Edge Functions with JWT/org-role validation, OAuth integrations, server-side token
encryption, authenticated media uploads, publishing queue workers, rate limiting,
and end-to-end/device tests.

Facebook personal-profile publishing is not supported by the official Page publishing API;
personal profiles require manual sharing.
