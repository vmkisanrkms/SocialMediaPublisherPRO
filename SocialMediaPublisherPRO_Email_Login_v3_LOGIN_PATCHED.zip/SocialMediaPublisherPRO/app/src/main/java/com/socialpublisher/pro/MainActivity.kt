package com.socialpublisher.pro

import android.os.Bundle
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import kotlinx.coroutines.launch
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Brand = androidx.compose.ui.graphics.Color(0xFF176B5B)
private val Ink = androidx.compose.ui.graphics.Color(0xFF182522)
private val Muted = androidx.compose.ui.graphics.Color(0xFF64736F)
private val SurfaceSoft = androidx.compose.ui.graphics.Color(0xFFF2F6F4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PublisherApp() }
    }
}

private data class NavItem(val label: String, val icon: ImageVector)

@Composable
fun PublisherApp() {
    val context = LocalContext.current
    val authRepo = remember { AuthRepository(context.applicationContext) }
    var loggedIn by remember { mutableStateOf(false) }
    var checkingSession by remember { mutableStateOf(true) }
    var signedInEmail by remember { mutableStateOf(authRepo.savedEmail()) }
    LaunchedEffect(Unit) {
        val restored = authRepo.restoreSession()
        loggedIn = restored.getOrNull() != null
        if (restored.isFailure) authRepo.signOut()
        checkingSession = false
    }
    if (checkingSession) {
        MaterialTheme(colorScheme = lightColorScheme(primary = Brand, onBackground = Ink)) {
            Box(Modifier.fillMaxSize().background(SurfaceSoft), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        return
    }
    if (!loggedIn) {
        MaterialTheme(colorScheme = lightColorScheme(primary = Brand, onBackground = Ink)) {
            LoginScreen(authRepo) { email -> signedInEmail = email; loggedIn = true }
        }
        return
    }
    val items = listOf(
        NavItem("Home", Icons.Default.Dashboard),
        NavItem("Create", Icons.Default.AddCircle),
        NavItem("Accounts", Icons.Default.Public),
        NavItem("Team", Icons.Default.Groups),
        NavItem("More", Icons.Default.Menu)
    )
    var selected by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Brand, onBackground = Ink)) {
        Scaffold(
            containerColor = SurfaceSoft,
            bottomBar = {
                NavigationBar(containerColor = androidx.compose.ui.graphics.Color.White) {
                    items.forEachIndexed { index, item ->
                        NavigationBarItem(
                            selected = selected == index,
                            onClick = { selected = index },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding)) {
                when (selected) {
                    0 -> DashboardScreen(onCreate = { selected = 1 })
                    1 -> CreatePostScreen()
                    2 -> AccountsScreen()
                    3 -> TeamScreen()
                    else -> MoreScreen(onSignOut = { authRepo.signOut(); loggedIn = false })
                }
            }
        }
    }
}

@Composable
private fun ScreenHeader(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun DashboardScreen(onCreate: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            ScreenHeader("Publisher Dashboard", "Your organisation's social media workspace")
        }
        item {
            Card(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = Brand),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text("One post. Multiple platforms.", color = androidx.compose.ui.graphics.Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Create platform-specific captions, review them and publish from one place.", color = androidx.compose.ui.graphics.Color.White.copy(alpha = .85f))
                    Spacer(Modifier.height(18.dp))
                    Button(onClick = onCreate, colors = ButtonDefaults.buttonColors(containerColor = androidx.compose.ui.graphics.Color.White, contentColor = Brand)) {
                        Icon(Icons.Default.Add, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Create Post")
                    }
                }
            }
        }
        item { SectionTitle("Publishing overview") }
        item {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Published", "0", Modifier.weight(1f))
                StatCard("Scheduled", "0", Modifier.weight(1f))
                StatCard("Failed", "0", Modifier.weight(1f))
            }
        }
        item { SectionTitle("Connected platforms") }
        item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PlatformRow("Facebook Page", "Not connected", Icons.Default.Facebook)
                PlatformRow("Instagram", "Not connected", Icons.Default.CameraAlt)
                PlatformRow("YouTube", "Not connected", Icons.Default.PlayCircle)
                PlatformRow("X (Twitter)", "Not connected", Icons.Default.Tag)
                PlatformRow("Facebook Profile", "Share manually", Icons.Default.Person)
            }
        }
        item {
            Text(
                "Setup mode • No social account has been connected yet",
                Modifier.padding(20.dp),
                color = Muted,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, Modifier.padding(start = 20.dp, top = 22.dp, bottom = 10.dp), fontWeight = FontWeight.Bold, color = Ink, fontSize = 17.sp)
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(value, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Brand)
            Text(label, fontSize = 11.sp, color = Muted)
        }
    }
}

@Composable
private fun PlatformRow(name: String, status: String, icon: ImageVector) {
    Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Brand)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.SemiBold, color = Ink)
                Text(status, color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
private fun CreatePostScreen() {
    var text by remember { mutableStateOf("") }
    var facebook by remember { mutableStateOf(true) }
    var instagram by remember { mutableStateOf(true) }
    var youtube by remember { mutableStateOf(false) }
    var x by remember { mutableStateOf(false) }
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item { ScreenHeader("Create Post", "One draft with platform-specific versions") }
        item {
            Column(Modifier.padding(horizontal = 16.dp)) {
                OutlinedTextField(
                    value = text, onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 150.dp),
                    label = { Text("Write your post") },
                    placeholder = { Text("Type your message here...") },
                    shape = RoundedCornerShape(16.dp)
                )
                Spacer(Modifier.height(16.dp))
                Text("Publish to", fontWeight = FontWeight.Bold, color = Ink)
                PlatformCheck("Facebook Page", facebook) { facebook = it }
                PlatformCheck("Instagram", instagram) { instagram = it }
                PlatformCheck("YouTube", youtube) { youtube = it }
                PlatformCheck("X (Twitter)", x) { x = it }
                PlatformCheck("Facebook Profile — share manually", false, enabled = false) {}
                Spacer(Modifier.height(14.dp))
                OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.AttachFile, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Add photo or video (integration pending)")
                }
                Spacer(Modifier.height(10.dp))
                Button(onClick = {}, modifier = Modifier.fillMaxWidth(), enabled = text.isNotBlank()) {
                    Icon(Icons.Default.Save, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Save Draft")
                }
                Text("Publishing is disabled until secure login and platform APIs are configured.", Modifier.padding(top = 10.dp), color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun PlatformCheck(label: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(enabled = enabled) { onChange(!checked) }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = onChange, enabled = enabled)
        Text(label, color = if (enabled) Ink else Muted, fontSize = 14.sp)
    }
}

@Composable
private fun AccountsScreen() {
    Column {
        ScreenHeader("Social Accounts", "Central organisation accounts only")
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Facebook Page", "Instagram Professional", "YouTube Channel", "X (Twitter)", "Facebook Profile sharing").forEach {
                Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(it, fontWeight = FontWeight.SemiBold)
                            Text("Not connected", color = Muted, fontSize = 12.sp)
                        }
                        Text("Connect", color = Brand, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun TeamScreen() {
    Column {
        ScreenHeader("Team Management", "Only Admin and Publisher can publish")
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Super Admin — Full control", "Admin — Manage accounts and team", "Publisher — Publish and schedule", "Editor — Create and edit drafts", "Viewer — Read only").forEach {
                Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                    Text(it, Modifier.fillMaxWidth().padding(16.dp), color = Ink, fontWeight = FontWeight.Medium)
                }
            }
            OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Invite team member (backend pending)") }
        }
    }
}

@Composable
private fun MoreScreen(onSignOut: () -> Unit) {
    Column {
        ScreenHeader("Workspace", "Scheduling, reports and settings")
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Schedule Calendar", "Publishing Reports", "Activity Log", "Notifications", "Settings", "Help & API Status").forEach {
                Card(colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(it, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                        Icon(Icons.Default.ChevronRight, null, tint = Muted)
                    }
                }
            }
            OutlinedButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Logout, null)
                Spacer(Modifier.width(8.dp))
                Text("Sign out")
            }
        }
    }
}


@Composable
private fun LoginScreen(repository: AuthRepository, onSuccess: (String) -> Unit) {
    var email by remember { mutableStateOf(repository.savedEmail()) }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Column(
        Modifier.fillMaxSize().background(SurfaceSoft).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Social Media", fontSize = 16.sp, color = Brand, fontWeight = FontWeight.Bold)
        Text("Publisher PRO", fontSize = 30.sp, color = Ink, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("अपने Workspace में सुरक्षित Login करें", color = Muted)
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(
            value = email, onValueChange = { email = it; error = null },
            modifier = Modifier.fillMaxWidth(), label = { Text("Email address") },
            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password, onValueChange = { password = it; error = null },
            modifier = Modifier.fillMaxWidth(), label = { Text("Password") },
            singleLine = true, visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
        )
        if (error != null) {
            Spacer(Modifier.height(10.dp))
            Text(error!!, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
        }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                loading = true; error = null
                scope.launch {
                    val result = repository.signIn(email, password)
                    loading = false
                    result.onSuccess { onSuccess(it.email) }
                        .onFailure { error = it.message ?: "Login नहीं हो पाया।" }
                }
            },
            enabled = !loading && email.isNotBlank() && password.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            if (loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
            else Text("Login with Email")
        }
        Spacer(Modifier.height(14.dp))
        TextButton(
            onClick = {
                loading = true; error = null
                scope.launch {
                    val result = repository.sendPasswordReset(email)
                    loading = false
                    error = result.fold(
                        onSuccess = { "Password reset link आपके Email पर भेज दिया गया है।" },
                        onFailure = { it.message ?: "Reset email नहीं भेजा जा सका।" }
                    )
                }
            },
            enabled = !loading && email.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Forgot Password?") }
        Text("यह Login आपके Supabase Auth Email/Password account का उपयोग करता है।", color = Muted, fontSize = 12.sp)
    }
}
