# Supabase backend status

The connected Supabase project has a dedicated private schema: `smp_private`.

Applied migration:
- `20261104070029_social_media_publisher_pro_foundation`

Tables created:
- organizations
- organization_members
- social_accounts
- oauth_credentials
- posts
- post_variants
- post_media
- post_reviews
- publish_jobs
- publish_results
- account_health
- activity_logs

Security model:
- Schema is not intended to be added to Data API exposed schemas.
- `anon` and `authenticated` have no schema usage.
- `service_role` has backend access only.
- RLS is enabled on all 12 tables.
- Edge Functions must verify the caller JWT and membership role before using service-role access.
- Never ship service-role keys or OAuth client secrets in the APK.
- Encrypt OAuth access/refresh tokens in the Edge Function before storing ciphertext in `oauth_credentials`.

Team roles:
- super_admin, admin, publisher, editor, viewer
- Only super_admin/admin/publisher may enqueue publishing jobs.
- Editors may create/edit drafts only.
- Viewers are read-only.

Not yet configured:
- Supabase Edge Functions and JWT/role enforcement
- Token encryption key
- Meta / Google / X OAuth credentials
- Storage bucket and upload policies
- Social platform app review / production permissions
- Initial organization bootstrap and first super-admin invitation

Important:
Facebook personal-profile publishing is not available through the official Page publishing API. Use Android share intent/manual confirmation for personal profiles.
