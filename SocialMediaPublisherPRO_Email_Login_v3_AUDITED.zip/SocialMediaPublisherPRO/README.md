# Social Media Publisher PRO

Native Android Kotlin + Jetpack Compose starter.

Package: `com.socialpublisher.pro`
Minimum Android: 6.0 (API 23)
Compile/Target SDK: 36
Build JDK: 17
Gradle: 8.11.1

## Current status
This is a UI/build foundation, not a production publishing client yet.
The screens are scaffolded for Dashboard, Create Post, Accounts, Team and Workspace.
Save Draft, account connection, team invitation and publishing actions are intentionally disabled until secure backend functions and OAuth providers are configured.

## Build
Run `gradle assembleDebug` with JDK 17 and Android SDK 36.
GitHub Actions workflow: `.github/workflows/android-build.yml`

## Backend
See `backend/README.md`. The connected Supabase project already has the private `smp_private` schema and 12 RLS-enabled tables.

## Required next steps
1. Implement authenticated Edge Functions and one-time organization bootstrap.
2. Add encrypted OAuth token storage and Meta/Google/X OAuth flows.
3. Add private media bucket and signed upload/download flow.
4. Implement draft, job queue, scheduler, retry and platform adapters.
5. Add role-based integration tests and release signing.
