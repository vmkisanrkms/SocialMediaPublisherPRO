package com.socialpublisher.pro

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class AuthSession(
    val accessToken: String,
    val refreshToken: String,
    val email: String,
    val expiresAt: Long
)

class AuthRepository(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        context,
        "publisher_secure_session",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun savedEmail(): String = prefs.getString("email", "") ?: ""
    fun hasSession(): Boolean = !prefs.getString("refresh_token", null).isNullOrBlank()
    fun accessToken(): String? = prefs.getString("access_token", null)
    fun organizationId(): String? = prefs.getString("organization_id", null)

    fun signOut() { prefs.edit().clear().apply() }

    suspend fun signIn(email: String, password: String): Result<AuthSession> = withContext(Dispatchers.IO) {
        runCatching {
            require(email.trim().contains("@") && email.length <= 254) { "सही Email दर्ज करें।" }
            require(password.isNotEmpty()) { "Password दर्ज करें।" }
            val response = request("/auth/v1/token?grant_type=password",
                JSONObject().put("email", email.trim()).put("password", password))
            saveSession(response, email.trim())
            val session = currentSession() ?: error("Login session save नहीं हो पाया।")
            val org = rpc("smp_bootstrap_org", JSONObject().put("p_org_name", "My Workspace"))
            val orgId = if (org is org.json.JSONObject) org.optString("id") else org.toString().trim('"')
            require(orgId.isNotBlank() && orgId != "null") { "Workspace तैयार नहीं हो पाया।" }
            prefs.edit().putString("organization_id", orgId).apply()
            session
        }
    }

    suspend fun restoreSession(): Result<AuthSession?> = withContext(Dispatchers.IO) {
        runCatching {
            val refresh = prefs.getString("refresh_token", null) ?: return@runCatching null
            val expiry = prefs.getLong("expires_at", 0L)
            if (expiry > System.currentTimeMillis() / 1000 + 90) {
                val access = prefs.getString("access_token", null)
                if (!access.isNullOrBlank()) return@runCatching currentSession()
            }
            val response = request("/auth/v1/token?grant_type=refresh_token",
                JSONObject().put("refresh_token", refresh))
            saveSession(response, savedEmail())
            currentSession()
        }
    }

    suspend fun sendPasswordReset(email: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(email.trim().contains("@")) { "पहले सही Email दर्ज करें।" }
            request("/auth/v1/recover",
                JSONObject().put("email", email.trim()).put("redirect_to", "socialpublisher://auth/reset"))
            Unit
        }
    }

    private fun currentSession(): AuthSession? {
        val access = prefs.getString("access_token", null) ?: return null
        val refresh = prefs.getString("refresh_token", null) ?: return null
        return AuthSession(access, refresh, savedEmail(), prefs.getLong("expires_at", 0L))
    }

    private fun saveSession(response: JSONObject, fallbackEmail: String) {
        val access = response.getString("access_token")
        val refresh = response.getString("refresh_token")
        val email = response.optJSONObject("user")?.optString("email", fallbackEmail) ?: fallbackEmail
        val expiresAt = System.currentTimeMillis() / 1000 + response.optLong("expires_in", 3600)
        prefs.edit().putString("access_token", access)
            .putString("refresh_token", refresh).putString("email", email)
            .putLong("expires_at", expiresAt).apply()
    }

    private fun rpc(function: String, body: JSONObject): Any {
        val conn = openConnection("/rest/v1/rpc/$function", "POST")
        conn.setRequestProperty("Authorization", "Bearer ${prefs.getString("access_token", "")}")
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }.orEmpty()
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException(parseError(raw))
        return runCatching { JSONObject(raw) }.getOrElse { raw }
    }

    private fun request(path: String, body: JSONObject): JSONObject {
        val conn = openConnection(path, "POST")
        conn.setRequestProperty("Authorization", "Bearer ${BuildConfig.SUPABASE_PUBLISHABLE_KEY}")
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }.orEmpty()
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException(parseError(raw))
        return JSONObject(raw)
    }

    private fun openConnection(path: String, method: String): HttpURLConnection {
        val conn = URL(BuildConfig.SUPABASE_URL + path).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 15000
        conn.readTimeout = 20000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
        return conn
    }

    private fun parseError(raw: String): String = runCatching {
        val json = JSONObject(raw)
        json.optString("msg").ifBlank {
            json.optString("message").ifBlank {
                json.optString("error_description").ifBlank { "Request असफल रहा। कृपया जानकारी जाँचें।" }
            }
        }
    }.getOrDefault("Request असफल रहा। कृपया दोबारा प्रयास करें।")
}
